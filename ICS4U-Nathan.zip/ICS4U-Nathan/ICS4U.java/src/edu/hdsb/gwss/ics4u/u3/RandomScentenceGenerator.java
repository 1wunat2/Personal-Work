/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.hdsb.gwss.ics4u.u3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author nwu10
 */
public class RandomScentenceGenerator {

    public static StringTokenizer word, n;

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        // FILE LIST
        ArrayList<String> fileList = listFilesInFolder(FILE_PATH);

        // GRAMMAR FILE - 6th - Extension Request
        File grammarFile = new File(FILE_PATH + fileList.get(13));

        // DATA TYPE FOR ASSIGNMENT
        HashMap<String, ArrayList<String>> grammar = new HashMap<>();

        // SCANNER for the GRAMMAR FILE
        Scanner input = new Scanner(grammarFile);

        // FIRST LINE IN FILE
//        System.out.println(nextLine(input));
        grammar = getData(input, null, "", false);
        String s = createSentence(grammar, "", true);
    }

    //STORES INPUT DATA IN HASHMAP
    public static HashMap getData(Scanner input, HashMap<String, ArrayList<String>> data, String code, boolean valid) {
        //VARIABLES
        String key, line = nextLine(input);
        ArrayList<String> list;

        //CREATE HASHMAP
        if (data == null) {
            data = new HashMap<>();
        }

        //CREATE NEW KEY AND LIST FOR HASHMAP
        if (line != null && line.equals("{")) {
            valid = true;
            key = nextLine(input);
            list = new ArrayList<>();
            data.put(key, list);
            data = getData(input, data, key, valid);
        }
        //END LIST FOR HASHMAP KEY
        if (line != null && line.equals("}") && input.hasNextLine()) {
            valid = false;
            data = getData(input, data, "", valid);
        }

        //STORE LINE IN ARRAYLISTAND PROCEED TO NEXT LINE
        if (line != null && input.hasNextLine() && valid) {
            data.get(code).add(line.replaceAll(";", ""));
            data = getData(input, data, code, valid);
        }
        //PROCEED TO NEXT LINE, DO NOT STORE CURRENT LINE IN ARRAYLIST
        if (line != null && input.hasNextLine() && !valid) {
            data = getData(input, data, code, valid);
        }

        //RETURN THE HASHMAP
        return data;
    }

    public static String createSentence(HashMap<String, ArrayList<String>> data, String sentence, boolean valid) {
//        StringTokenizer word;
        String STR, s = "";

        if (sentence.equals("")) {
            sentence = data.get("<start>").get(randomNum(data.get("<start>").size()));
        }

        if (valid) {
            word = new StringTokenizer(sentence);
        }

        if (!word.hasMoreTokens()) {
            return "";
        }
        STR = word.nextToken();

        if (data.containsKey(STR)) {
            n = word;
            s = createSentence(data, data.get(STR).get(randomNum(data.get(STR).size())), true);
            word = n;
        }

        if (!data.containsKey(STR)) {
            s = STR + " " + createSentence(data, sentence, false);
        }

        if (word.hasMoreTokens()) {
            s = " " + createSentence(data, sentence, false);
        }

        return s;
    }

    //GENERATES A RANDOM INT NUMBER
    public static int randomNum(int n) {
        return (int) (Math.random() * n);
    }

    /**
     * RETURN THE NEXT LINE that has useful data.
     *
     * @param input
     * @return the next line, or NULL if there is no useful data.
     */
    public static String nextLine(Scanner input) {

        String s = null;
        boolean complete = false;

        while (!complete) {
            if (input.hasNextLine()) {
                s = input.nextLine();
                if (s.trim().length() > 0) {
                    complete = true;
                }
            } else {
                complete = true;
            }
        }

        if (s != null && s.length() == 0) {
            s = null;
        }

        return s;

    }

    /**
     * NO NEED TO UNDERSTAND BELOW
     *
     * @param path
     * @return
     */
    public static ArrayList<String> listFilesInFolder(String path) {

        // DATA FOLDER
        File folder = new File(path);

        // FILE LISTING
        ArrayList<String> fileList = new ArrayList<>();

        // LOAD GRAMMAR FILES
        for (final File fileEntry : folder.listFiles()) {
            fileList.add(fileEntry.getName());
        }

        // SORT
        Collections.sort(fileList);

        return fileList;

    }

    // CLASS CONSTANTS
    private static final String FS = File.separator;
    private static final String FILE_PATH = "." + FS + "data" + FS + "random.sentence.generator" + FS;

}
