/*
 * ICS4U - 2020.21.Q1
 */
package edu.hdsb.gwss.ics4u;

/**
 * @author Wm.Muir
 */
public class Welcome {

    public static void main( String[] args ) {

        System.out.println( "Welcome to ICS4U!" );

    }

}
